from tensroflow.examples.tutorials.mnist import input_data
import tensorflow as tf
mnist=input_data.read_data_sets('data/',one_hot=True)
sess=tf.InteractiveSession()

class TextCNN(object):

    self.shape

    def __init__(self, shape, num_classes, num_filters, act=tf.nn.relu, vocab_size=1433, filter_sizes=4):

        self.input_x = tf.placeholder(tf.int32, [None, vocab_size], name="input_x")
        self.input_y = tf.placeholder(tf.float32, [None, num_classes], name="input_y")
        self.dropout_keep_prob = tf.placeholder(tf.float32, name="dropout_keep_prob")


        self.input_x = tf.reshape(x,[-1,28,28,1])
        return super().__init__(*args, **kwargs)
    
    """定义权重"""
    def weight_variable(shape):
        init_range = np.sqrt(6.0/(shape[0]+shape[1]))
        initial = tf.random_uniform(shape, minval=-init_range, maxval=init_range, dtype=tf.float32)
        return tf.Variable(initial, name='weights')

    """定义偏置"""
    def bias_variable(shape):
        initial = tf.zeros(shape, dtype=tf.float32)
        return tf.Variable(initial, name='bias')

    """定义损失"""
    def loss_function(self):
        pass

    """定义卷积"""
    def conv2d(self):
        return tf.nn.conv2d(x,W,strides=[1,1,1,1],padding='SAME')

    """定义池化"""
    def max_pool_2x2(self):
        pass

    def train(self):
        pass

    def test(self):
        pass


